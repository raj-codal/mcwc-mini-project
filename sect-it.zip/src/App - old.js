import React from 'react';
// import logo from './logo.svg';
import './App.css';
import Main from './components/Main';
import Events from './components/Events';
import {animated} from "react-spring";
import {Transition} from "react-spring/renderprops";

class App extends React.Component {
  constructor(props) {
    super(props)
  
    this.state = {
       showEvents:false,
       showForm:false
    }
  }

  toggleEvn = e => this.setState({
    showEvents:!this.state.showEvents
  });


  
  render(){
    return (
      <main>
      <div className="position-relative">
        <Main toggleEvn={this.toggleEvn} />
        {/* <Events /> */}

        <Transition
          config={{duration: 1000}}
          items={this.state.showEvents}
          from={{marginTop: -500}}
          enter={{marginTop: 0}}
          leave={{marginTop: -500}}
        >
          {
            show => show && 
            ( props => (
              <animated.div style={props}>
                <Events direction={{down: this.state.showEvents}}/>
              </animated.div>  
            )) 
          }
        </Transition>

      </div>
      </main>
    );
  }
}

export default App;
