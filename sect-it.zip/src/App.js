import React from 'react';
// import logo from './logo.svg';
import './App.css';
import Main from './components/Main';
import Events from './components/Events';
// import {animated} from "react-spring";
// import {Transition} from "react-spring/renderprops";
import Forms from './components/Forms';
import { Link, Element, animateScroll as scroll } from "react-scroll"
import Team from './components/Team';
import Footer from './components/Footer';


class App extends React.Component {
  constructor(props) {
    super(props)
  
    // this.state = {
       
    // }
  }

  // toggleEvn = e => this.setState({
  //   showEvents:!this.state.showEvents
  // });

  toggleEvn = (e) => {
    document.getElementById('events').focus();
  }
  
  render(){
    return (
      <main>
       <div className="position-relative">
        {/*<header className="header-global" style={{position:"fixed",zIndex:25}}>
          <nav className="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom headroom--not-bottom headroom--pinned headroom--top" id="navbar-main">
                <div className="container">
                <a className="navbar-brand mr-lg-5">
                    <img src="https://avatars2.githubusercontent.com/u/43428556?s=400&u=b18c32e60aceaa993c1d9e14470c4a0c0ade46bd&v=4" onClick={this.scrollToTop} />
                </a>
                <button className="navbar-toggler" aria-expanded="false" aria-controls="navbar_global" aria-label="Toggle navigation" type="button" data-target="#navbar_global" data-toggle="collapse">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="navbar-collapse collapse" id="navbar_global">
                    <div className="navbar-collapse-header">
                    <div className="row">
                        <div className="col-6 collapse-brand">
                        <a href="./index.html">
                          <img src="https://avatars2.githubusercontent.com/u/43428556?s=400&u=b18c32e60aceaa993c1d9e14470c4a0c0ade46bd&v=4" onClick={this.scrollToTop} />
                        </a>
                        </div>
                        <div className="col-6 collapse-close">
                        <button className="navbar-toggler" aria-expanded="false" aria-controls="navbar_global" aria-label="Toggle navigation" type="button" data-target="#navbar_global" data-toggle="collapse">
                            <span></span>
                            <span></span>
                        </button>
                        </div>
                    </div>
                    </div>
                    
                    <ul className="navbar-nav align-items-lg-center ml-lg-auto">
                    <li className="nav-item">
                    <Link activeClass="active" className="test1" to="test1" spy={true} smooth={true} duration={500}>
                        <a title="" className="nav-link nav-link-icon" data-toggle="tooltip" data-original-title="Register Now">
                          <i className="fa navElements" >EVENTS</i>
                        </a>
                    </Link>
                    </li>
                    <li className="nav-item">
                    <Link activeClass="active" className="test2" to="test2" spy={true} smooth={true} duration={500}>
                        <a title="" className="nav-link nav-link-icon" data-toggle="tooltip" data-original-title="Register Now">
                          <i className="fa navElements" >REGISTER</i>
                        </a>
                    </Link>   
                    </li>
                    <li className="nav-item">
                        <a title="" className="nav-link nav-link-icon" data-toggle="tooltip" data-original-title="Register Now">
                          <i className="fa navElements" >CHECK REGISTRATION</i>
                        </a>
                    </li>
                    </ul>
                </div>
                </div>
            </nav>

        </header> */}
<nav class="navbar navbar-expand-lg navbar-dark bg-default fixed-top">
    <div class="container">
        <img src="/assets/img/logowhite.png" style={{height:"50px"}}></img>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-default">
            <div class="navbar-collapse-header">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        CONVERSE 2K19
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>

            <ul className="navbar-nav align-items-lg-center ml-lg-auto">
                    <li className="nav-item">
                    <Link activeClass="active1" className="test1" to="test1" spy={true} smooth={true} duration={500}>
                        <a title="" className="nav-link nav-link-icon">
                          <i className="fa navElements" >EVENTS</i>
                        </a>
                    </Link>
                    </li>
                    <li className="nav-item">
                    <Link activeClass="active1" className="test2" to="test2" spy={true} smooth={true} duration={500}>
                        <a title="" className="nav-link nav-link-icon">
                          <i className="fa navElements" >REGISTER</i>
                        </a>
                    </Link>   
                    </li>
                    <li className="nav-item">
                        <a title="" className="nav-link nav-link-icon">
                          <i className="fa navElements" >CHECK REGISTRATION</i>
                        </a>
                    </li>
            </ul>

        </div>
    </div>
</nav>

        <Main 
          // linkDataEvent={<Link activeClass="active" className="test1" to="test1" spy={true} smooth={true} duration={500} >
          //   <button className="btn btn-lg btn-white btn-icon mb-3 mb-sm-0" style={{width: '200px',borderRadius: '25px'}} onClick={this.scrollToEvents}>
          //     <span className="btn-inner--text">
          //     <span className="text-primary">CHECK EVENTS</span></span>
          //   </button><br/>
          // </Link>} 
          linkDataRegister={<Link activeClass="active" className="test2" to="test2" spy={true} smooth={true} duration={500} >
            <button className="btn btn-lg btn-white btn-icon mt-3 mb-3 mb-sm-0" style={{width: '200px',borderRadius: '25px'}} onClick={this.props.toggleEvn}>
              <span className="btn-inner--text">
              <span className="text-primary">REGISTER NOW</span></span>
            </button>
          </Link>} 
        />
        <div className="container mt-5">
          <div className="row mt-5">
            <div className="col-lg-8 col-md-12 ml-auto mr-auto"><center><h2>About Converse</h2><br/><h4>Converse is an annual event organized by Information Technology Department, Sarvajanik College of Engineering & Technology, Surat, which features Technical and non-Technical events providing students with opportunities to improve as well as showcase their skills.</h4></center></div>
          </div>
        </div>
        <Element name="test1" className="element" >
          <Events title="section1" />
        </Element>
        <Element name="test2" className="element" >
          {/* <Forms /> */}
          <hr/>
          <center><h3 style={{color:"red"}}>REGISTRATION WILL START SOON...</h3></center>
        </Element>
        <Team/>
        <Footer/>

        {/* <Transition
          config={{duration: 1000}}
          items={this.state.showEvents}
          from={{marginTop: -500}}
          enter={{marginTop: 0}}
          leave={{marginTop: -500}}
        >
          {
            show => show && 
            ( props => (
              <animated.div style={props}>
                <Events direction={{down: this.state.showEvents}}/>
              </animated.div>  
            )) 
          }
        </Transition> */}

      </div>
      </main>
    );
  }
}

export default App;
