import React, { Component } from 'react';
// import { Modal, Button } from 'antd';
import Modals from './Modals';
import PosterModal from './PosterModal';
// import nontech from './data/nontech.json';

class Events extends Component {
    componentDidMount(){
        
    }

    constructor(props) {
        super(props)
      
        // this.state = { visible: false };
    }

    // state = { visible: false };

    // showModal = () => {
    //     console.log("CLICKED");
    //     this.setState({
    //     visible: true,
    //     });
    // };

    // handleOk = e => {
    //     console.log(e);
    //     this.setState({
    //     visible: false,
    //     });
    // };

    // handleCancel = e => {
    //     console.log(e);
    //     this.setState({
    //     visible: false,
    //     });
    // };
    
    
    render() {
        // i = 0;
        // minimilitia = nontech.minimilitia.map(e => (
        //                     <li key={e}>e</li>
        //                 ))
      

        return (
            <section className="main" id = "events" >
                <br/>
                <div className="container">

                <div className="mt-5 mb-2" style={{textAlign: "center",zIndex: 20}}><h2>TECHNICAL EVENTS</h2></div>
                {/* <hr className="thick" /> */}
                <div className="row pl-3 pr-3" style={{zIndex: 20,background: '#ffffff'}}>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            <PosterModal image="eventposters/pyit.jpeg"/>
                            <div className="card-body">
                                <h5><center>PY IT</center></h5>
                                <Modals eventname="PY IT" 
                                rules={[
                                    "Team Size: Individual",
                                    "Awards & Prizes: Top 3 participants of Round 3 will be awarded prizes",
                                    "top 20 participants of Round 1 will be awarded participants certificates.",
                                    "Round 1: Aptitude Round : Online test of General Aptitude, Logical & Verbal Reasoning,  Current affairs and General Knowledge.",
                                    "Total Questions: 30, Time : 45 Minutes",
                                    "Each correct answer carries 1 mark, and incorrect answer -0.25 marks. \n Best 20 participants will be selected for next round",
                                    "Round 2: Group Discussion : GD will be on general topics related to social, economics, politics, sports, education  etc. Topics for GD will be given in advance before 24 hours.(if qualified in 1st round).",
                                    "Total two rounds in group of 10 participants. Time : 20 Minutes for each round. ",
                                    "Best 10 participants will be selected for next round.",
                                    "Round 3: Personal Interview : General PI Questions will be asked to test confidence, attitude, personality, strength, weaknesses, creativity, soft skills etc. ",
                                    "Participants have to appear with proper formal dressing and bring the curriculum vitae.",
                                ]}
                                ></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            {/* <img className="card-img-top" src="eventposters/relay.jpeg" alt="Card image" /> */}
                            <PosterModal image="eventposters/relay.jpeg"/>
                            <div className="card-body">
                                <h5><center>RELAY CODING</center></h5>
                                <Modals eventname="Relay Coding" rules={[
                                    "Each team shall consist of Maximum 2 members ",
                                    "There will be only single round",                                    
                                    "In a team of 2 members, first participant will be given 40 minutes and the remaining part will be completed by the next participant.",                                    
                                    "Time Limit: 1 hour 30 Minutes"
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            {/* <img className="card-img-top" src="eventposters/wysiwyg.jpeg" alt="Card image" /> */}
                            <PosterModal image="eventposters/wysiwyg.jpeg"/>
                            <div className="card-body">
                                <h5><center>WYSIWYG</center></h5>
                                <Modals eventname="WYSIWYG" rules={[
                                    "2 participants per team.", 
                                    "On the spot Theme will be provided.", 
                                    "Time Limit: 2 hours. ",
                                    "Participants will have to build home page and 2-3 subpages on it. ",
                                    "Design a website using any tool (WordPress, HTML & CSS, Visual Studio IDE etc.) ",
                                    "Ready-made online templates will not be entertained. ",
                                    "Bring the setup of tool / technology by your own if required. (Except Dreamweaver, Visual Studio IDE) "
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            {/* <img className="card-img-top" src="eventposters/itquiz.jpeg" alt="Card image" /> */}
                            <PosterModal image="eventposters/itquiz.jpeg"/>
                            <div className="card-body">
                                <h5><center>IT QUIZ</center></h5>
                                <Modals eventname="IT QUIZ" rules={[
                                    "The Event is for individual students",
                                    "These event is for all students of BE all year ( All branches)",
                                    "Quiz will be based on Questions related to basic of Information Technology and Computer.",
                                    "There will be only single round",
                                    "Total 25 Questions",
                                    "Time Limit: 20 Minutes",
                                    "There will be penalty for each wrong answer",
                                    "No On the Spot Entry",
                                    "Participation Certificates will be awarded"
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            {/* <img className="card-img-top" src="eventposters/cquiz.jpeg" alt="Card image" /> */}
                            <PosterModal image="eventposters/cquiz.jpeg"/>
                            <div className="card-body">
                                <h5><center>C QUIZ</center></h5>
                                <Modals eventname="C Quiz" rules={[
                                    "The Event is for individual students ",
                                    "Only for students of BE 1st year ( All branches) ",
                                    "Quiz will be based on Questions related to basic C languages",
                                    "There will be only single round ",
                                    "Total 40 Questions",
                                    "Time Limit: 30 Minutes",
                                    "Correct Answer : 1 mark & Incorrect Answer : -0.25 mark",
                                    "No On the Spot Entry",
                                    "Top 3 participants will be awarded prizes and Top 10% participants will be awarded participants certificates"
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5" id="last">
                        <div className="card card-lift--hover shadow border-2">
                            {/* <img className="card-img-top" src="eventposters/imageit.jpeg" alt="Card image" /> */}
                            <PosterModal image="eventposters/imageit.jpeg"/>
                            <div className="card-body">
                                <h5><center>IMAGE IT</center></h5>
                                <Modals eventname="event 1" rules="rule number 1"></Modals>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>

                <br/>

                <hr/>

                <div className="container">

                <div className="mt-5 mb-2" style={{textAlign: "center",zIndex: 20}}><h2>NON-TECHNICAL EVENTS</h2></div>
                {/* <hr className="thick" /> */}
                <div className="row pl-3 pr-3" style={{zIndex: 20,background: '#ffffff'}}>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            <img className="card-img-top" src="eventposters/mini.jpeg" alt="Card image" />
                            <div className="card-body">
                                <h5><center>Mini Militia</center></h5>
                                <Modals eventname="mini militia" 
                                    rules={[
                                        "Each team shall consist of Maximum 4 members.", 
                                        "The tournament will be a Knockout-cum-Round Robin.",
                                        "Matches would be fixed between teams on the basis of draw of lots.",
                                        "The winner of the match would be decided on the basis of kills gained by each team in a given match.",
                                        "Only two teams would participate in a match at a time.",
                                        "Teams qualifying for semi-finals shall choose a map of their preference in subsequent matches. The right of choosing the map of preference would be decided by a coin toss between the teams.",
                                        "Each match shall be of 10 minutes.", 
                                        "Any upgrades with relation to the game 'Doodle Army 2:Mini Militia are strictly prohibited. The organizers shall check for the same and if any player is found using the upgraded version of the game, his/her team will be immediately disqualified.", 
                                        "INDEPENDENT OBSERVER: The game would be monitored by an independent observer from the organizing committee. The independent observer would be not participate in the match and his presence shall not influence the outcome of the match in any way whatsoever; kills gained by eliminating the observer would not be counted.",
                                        "The observer would be dressed in a distinct Avatar to avoid confusion of any sorts.",
                                        "Players of the same team would be required to create identical Avatars for the ease of monitoring.",
                                        "The prize money for the event would be the pot amount of all the registrations.",
                                        "Any difficulties, technical or otherwise, would not fasten any liability on the organizers.",
                                        "If in case a match lags more than three times, the match would be canceled leading to a fresh rematch.",
                                        "The aforementioned rules are subject to change as and when the need arises. The right of making alterations to the rules and overall conduct of the game shall lie with the organizing committee."
                                    ]}
                                ></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            <img className="card-img-top" src="eventposters/pucket.jpeg" alt="Card image" />
                            <div className="card-body">
                                <h5><center>Pucket</center></h5>
                                <Modals eventname="Pucket" 
                                    rules={[
                                        "Find an opponent.",
                                        "Start with eight pucks (the wooden discs) each side of the board.",
                                        "Shout “GO” and then use the elastic to fire pucks through the gate until there are no more pucks on your side.",
                                        "Don’t take it in turns – just reload and fire as fast as you possibly can.",
                                        "If a puck flies off the board, the player who sent it must retrieve it.",
                                        "You’re not allowed to push pucks forwards with your hand, but you can move pucks to the side of the board to clear space if required. Jeering and shouting at your opponent is allowed."
                                    ]}
                                ></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            <img className="card-img-top" src="eventposters/bounce.jpeg" alt="Card image" />
                            <div className="card-body">
                                <h5><center>Bouncer Minute to Win it</center></h5>
                                <Modals eventname="event 1" 
                                    rules={[
                                        "The Ping Pong ball must bounce on the table and land in the glass.",
                                        "In team mode, the players may not bounce balls into each other’s glasses."
                                    ]}
                                ></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            <img className="card-img-top" src="eventposters/roll.jpeg" alt="Card image" />
                            <div className="card-body">
                                <h5><center>Roll the dice</center></h5>
                                <Modals eventname="event 1" rules={[
                                    "Roll the Dice is a simple dice game, two 6 sided dice are rolled and the results are totaled up. You can predict on the total being over 7, under 7 or exactly seven"
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5">
                        <div className="card card-lift--hover shadow border-2">
                            <img className="card-img-top" src="eventposters/auction.jpeg" alt="Card image" />
                            <div className="card-body">
                                <h5><center>Auction Pitch</center></h5>
                                <Modals eventname="Auction Pitch" rules={[
                                    "Team size should be of 2 members.",
                                    "You must buy minimum 2 players.",
                                    "players can have different credits.",
                                    "the buyer with maximum credit score  will go for next round.",
                                    "only 100 points will be given for auction per team."
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-5 col-sm-8 mr-auto ml-auto mt-5" id="last">
                        <div className="card card-lift--hover shadow border-2">
                            <img className="card-img-top" src="eventposters/shoot.jpeg" alt="Card image" />
                            <div className="card-body">
                                <h5><center>Shoot the bottle caps</center></h5>
                                <Modals eventname="Shoot the bottle caps" rules={[
                                    "Step 1 : Obtain an empty plastic bottle",
                                    "Step 2 : Remove the label from the bottle",
                                    "Step 3 : Squeeze the bottle in the middle and twist",
                                    "Step 4 : Twist the bottle about 4 to 6 times",
                                    "Step 5 : Untwist the cap with your thumb"
                                ]}></Modals>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
                <br/>
                <br/>
                {/* <center><p style={{color:"#ff5252"}}><b>NO CERTIFICATE WILL BE PROVIDED FOR NON TECHNICAL EVENTS !!</b></p></center> */}
            </section>
        )
    }
}

export default Events



