import React, { Component } from 'react'

export default class Footer extends Component {
    render() {
        return (
            <footer className="mt-5">
                <div className="footer-copyright text-center py-3 footerBox">
                     <b style = {{color : "white"}}> Made By : Dharm Valani, Raj Dhanani and Swar Gondaliya</b>
                </div>
            </footer>
        )
    }
}
