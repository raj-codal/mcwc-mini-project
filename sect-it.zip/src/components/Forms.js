import React, { Component } from 'react'
import Axios from 'axios';
import { Spin, Icon, Result, Alert } from 'antd';
import { Element, scroller } from "react-scroll"


export default class Forms extends Component {
    
    constructor(props){
        super(props);
        // this.resultRef = React.createRef();
        this.refrence = React.createRef();
        this.state = {
            response : {},
            message: null,
            gotResponse: false,
            registering: false,
            registered: false,
            selectedEvent: null
        }

    }

    componentDidUpdate(){
        if(this.state.gotResponse){
            scroller.scrollTo('sub', {
                duration: 500,
                smooth: true,
                offset: -50, 
            })
        }
    }
    
    register = e => {
        this.setState({
            registering : true,
            registered : false,
            gotResponse : false 
        });
        e.preventDefault();
        let name = document.getElementById("name");
        let event = document.getElementById("event");
        let dept = document.getElementById("dept");
        let email = document.getElementById("email");
        let phone = document.getElementById("phone");
        let enrollment = document.getElementById("enrollment");
        let year = document.querySelectorAll("input[name=year]:checked")[0];
        var data = new FormData();
        data.append(name.id,name.value);
        data.append(event.id,event.value);
        data.append(email.id,email.value);
        data.append(phone.id,phone.value);
        data.append(enrollment.id,enrollment.value);
        data.append(dept.id,dept.value);
        data.append("year",year.value);
        if(
            event.value === "wysiwyg" ||
            event.value === "relaycoding" ||
            event.value === "imageit"
            ){
                let name1 = document.getElementById("name1");
                let email1 = document.getElementById("email1");
                let phone1 = document.getElementById("phone1");
                let enrollment1 = document.getElementById("enrollment1");
                let dept1 = document.getElementById("dept1");
                let year1 = document.querySelectorAll("input[name=year1]:checked")[0]
                data.append(name1.id,name1.value);
                // data.append(event1.id,event.value);
                data.append(email1.id,email1.value);
                data.append(dept1.id,dept1.value);
                data.append(phone1.id,phone1.value);
                data.append(enrollment1.id,enrollment1.value);
                data.append("year1",year1.value);
            }
        // console.log(data);
        Axios.post("https://script.google.com/macros/s/AKfycbzVulvLWx4cf80balepa1kMbr0Ktu_8Zr6st9wAoqSOa8tFzkZ8/exec",data)
        .then(res => {
            console.log(res.data)
            var responseData = res.data;
            if(responseData.ERROR){
                this.setState(
                    {
                        error: "SOMETHING WENT WRONG!"
                    }
                )
            }
            else{
                this.setState({
                    message: responseData,
                    registering: false,
                    registered: true
                })
            }
        })
        .catch(res =>{
            console.log(res)
        })
        this.setState({
            gotResponse: true
        })
        console.log(this.state)
    }

    eventselected = e => {
        // console.log(e.target.value);
        this.setState({
            selectedEvent: e.target.value
        })
    }

    
        // console.log();
    

    render() {
        var classname = "";
        var submitbuttondata = "";
        var resullt = "";
        if(this.state.registering){
            const antIcon = <Icon type="loading" style={{ fontSize: 24 }} spin />;
            submitbuttondata = <Spin indicator={antIcon}/>
            classname = "btn btn-lg btn-white btn-icon mb-3 mb-sm-0";
        }
        else{
            submitbuttondata = 'SUBMIT'
            classname = "btn btn-lg btn-primary btn-icon mb-3 mb-sm-0";
            if(this.state.registered){
                if(this.state.message.isValid === true){
                    resullt = <Result
                                        icon={<Icon type="smile" theme="twoTone" />}
                                        title={"Registered Successfully! your ID = IT" + this.state.message.id}
                                    />
                }
                else{
                    let errorsR = this.state.message.isValid.toString().split('!');
                    errorsR.pop();
                    const listItems = errorsR.map((e) =>
                        <Alert key={e.toString()} message={e} type="error"/>
                    );
                    console.log("ls:"+listItems);
                    resullt = <Result
                                    status="warning"
                                    title="Error."
                                    extra={
                                        <div>
                                            {listItems}
                                        </div>
                                    }
                                />
                }
            }
        }

        var single =
                <> 
                <div className="offset-md-2 col-md-8">
                      <h5>Name:</h5>
                      <input required type="text" className="form-control mb-3" id="name" style={{color:'black'}} placeholder="Enter your name"/>
                </div>

                <div className="offset-md-2 col-md-8">
                      <h5>Year:</h5>
                      
                      <p>
                        <input required type="radio" className="yr ml-3" name="year" value="1" onClick={this.yearfun}/>1st
                        <input required type="radio" className="yr ml-3" name="year" value="2" onClick={this.yearfun}/>2nd
                        <input required type="radio" className="yr ml-3" name="year" value="3" onClick={this.yearfun}/>3rd
                        <input required type="radio" className="yr ml-3" name="year" value="4" onClick={this.yearfun}/>4th
                      </p>
                </div>
                <div className="offset-md-2 col-md-8">
                <h5>Department:</h5>
                <select required  className="form-control mb-3" id="dept" style={{color:'black'}}>
                            <option value="" disabled selected>Select Your Department</option>
                            <option value="IT">IT</option>
                            <option value="CO">CO</option>
                            <option value="MCA">MCA</option>
                            <option value="ELE">ELE</option>
                            <option value="EC">EC</option>
                            <option value="IC">IC</option>
                            <option value="MECH">MECH</option>
                            <option value="CIVIL">CIVIL</option>
                            <option value="CHEM">CHEM</option>
                            <option value="TT">TT</option>
                </select>
                </div>
                <div className="offset-md-2 col-md-8">
                      <h5>Enrollment:</h5>
                      <input required type="number" maxLength={12} className="form-control mb-3" id="enrollment" style={{color:'black'}} placeholder="Enter Your Enrollment Number"/>
                </div>
                <div className="offset-md-2 col-md-8">
                      <h5>Email:</h5>
                      <input required type="email" className="form-control mb-3" id="email" style={{color:'black'}} placeholder="name@example.com"/>
                </div>
                <div className="offset-md-2 col-md-8">
                      <h5>Contact Number:</h5>
                <Element name="sub" className="element" >
                      <input required minLength={10} maxLength={10} type="number" className="form-control mb-3" id="phone" style={{color:'black'}} placeholder="Your Mo. No."/>
                </Element>
                </div>
                <div className="offset-md-2 col-md-8" style={{textAlign:'center'}}>
                    <button id='submit' className={classname} ref={this.refrence} style={{width: '200px',borderRadius: '25px'}}>
                        <span className="btn-inner--text">{submitbuttondata}</span>
                    </button>
                    {resullt}
                    
                </div>
                </>

var double =
            <>
            <div className="col-md-8 col-lg-6 ml-auto mr-auto"> 
            <h4>Member 1</h4>
                <div className="mr-3 ml-3">
                    <h5>Name:</h5>
                    <input required type="text" className="form-control mb-3" id="name" style={{color:'black'}} placeholder="Enter your name"/>
                </div>

                <div className="mr-3 ml-3">
                      <h5>Year:</h5>
                      
                      <p>
                        <input required type="radio" className="yr ml-3" name="year" value="1" onClick={this.yearfun}/>1st
                        <input required type="radio" className="yr ml-3" name="year" value="2" onClick={this.yearfun}/>2nd
                        <input required type="radio" className="yr ml-3" name="year" value="3" onClick={this.yearfun}/>3rd
                        <input required type="radio" className="yr ml-3" name="year" value="4" onClick={this.yearfun}/>4th
                      </p>
                </div>
                <div className="mr-3 ml-3">
                <h5>Department:</h5>
                <select required className="form-control mb-3" id="dept" style={{color:'black'}}>
                            <option value="" disabled selected>Select Your Department</option>
                            <option value="IT">IT</option>
                            <option value="CO">CO</option>
                            <option value="MCA">MCA</option>
                            <option value="ELE">ELE</option>
                            <option value="EC">EC</option>
                            <option value="IC">IC</option>
                            <option value="MECH">MECH</option>
                            <option value="CIVIL">CIVIL</option>
                            <option value="CHEM">CHEM</option>
                            <option value="TT">TT</option>
                </select>
                </div>
                <div className="mr-3 ml-3">
                    <h5>Enrollment:</h5>
                    <input required type="number" className="form-control mb-3" id="enrollment" style={{color:'black'}} placeholder="Enter Your Enrollment Number"/>
                </div>
                <div className="mr-3 ml-3">
                    <h5>Email:</h5>
                    <input required type="email" className="form-control mb-3" id="email" style={{color:'black'}} placeholder="name@example.com"/>
                </div>
                <div className="mr-3 ml-3">
                    <h5>Contact Number:</h5>
                    <input required size="10" type="number" className="form-control mb-3" id="phone" style={{color:'black'}} placeholder="Your Mo. No."/>
                </div>
            </div>
            <div className="col-md-8 col-lg-6 ml-auto mr-auto"> 
                <h4>Member 2</h4>
                <div className="mr-3 ml-3">
                    <h5>Name:</h5>
                    <input required type="text" className="form-control mb-3" id="name1" style={{color:'black'}} placeholder="Enter your name"/>
                </div>

                <div className="mr-3 ml-3">
                      <h5>Year:</h5>
                      
                      <p>
                        <input required type="radio" className="yr ml-3" name="year1" value="1" onClick={this.yearfun}/>1st
                        <input required type="radio" className="yr ml-3" name="year1" value="2" onClick={this.yearfun}/>2nd
                        <input required type="radio" className="yr ml-3" name="year1" value="3" onClick={this.yearfun}/>3rd
                        <input required type="radio" className="yr ml-3" name="year1" value="4" onClick={this.yearfun}/>4th
                      </p>
                </div>
                <div className="mr-3 ml-3">
                <h5>Department:</h5>
                <select required className="form-control mb-3" id="dept1" style={{color:'black'}}>
                            <option value="" disabled selected>Select Your Department</option>
                            <option value="IT">IT</option>
                            <option value="CO">CO</option>
                            <option value="MCA">MCA</option>
                            <option value="ELE">ELE</option>
                            <option value="EC">EC</option>
                            <option value="IC">IC</option>
                            <option value="MECH">MECH</option>
                            <option value="CIVIL">CIVIL</option>
                            <option value="CHEM">CHEM</option>
                            <option value="TT">TT</option>
                </select>
                </div>
                <div className="mr-3 ml-3">
                    <h5>Enrollment:</h5>
                    <input required type="number" className="form-control mb-3" id="enrollment1" style={{color:'black'}} placeholder="Enter Your Enrollment Number"/>
                </div>
                <div className="mr-3 ml-3">
                    <h5>Email:</h5>
                    <input required type="email" className="form-control mb-3" id="email1" style={{color:'black'}} placeholder="name@example.com"/>
                </div>
                <div className="mr-3 ml-3">
                    <h5>Contact Number:</h5>
                <Element name="sub" className="element" >
                    <input required size="10" type="number" className="form-control mb-3" id="phone1" style={{color:'black'}} placeholder="Your Mo. No."/>
                </Element>
                </div>
            </div>
            <div className="offset-md-2 col-md-8" style={{textAlign:'center'}}>
                    <button id='submit' className={classname} ref={this.refrence} style={{width: '200px',borderRadius: '25px'}}>
                        <span className="btn-inner--text">{submitbuttondata}</span>
                    </button>
                    {resullt}
                    
                </div>
            </>

        

        if(this.state.selectedEvent === "itquiz" 
            || this.state.selectedEvent === "cquiz"
            || this.state.selectedEvent === "pyit"){
            var forminput = single;
        } else if (
            this.state.selectedEvent === "wysiwyg" 
            || this.state.selectedEvent === "relaycoding"
            || this.state.selectedEvent === "imageit"
        ){
            var forminput = double;
        }



        return (
            <>
    <hr/>
        <h2 style={{textAlign:'center'}}>REGISTER HERE</h2>
        <form id="regdata" style={{padding:'25px',margin:'25px'}} onSubmit={this.register}>
            <div className="row align-items-center">
              

                <div className="col-md-8 ml-auto mr-auto">
                      <h5>Event:</h5>
                      <select className="form-control mb-3" id="event" placeholder="select event" onChange={this.eventselected} style={{color:'black'}}>
                            <option value="" disabled selected>Select Event</option>
                            <option value="itquiz">IT Quiz</option>
                            <option value="wysiwyg">WYSIWYG</option>
                            <option value="pyit">PYIT</option>
                            <option value="imageit">Image IT</option>
                            <option value="relaycoding">Relay Coding</option>
                            <option value="cquiz">C Quiz</option>
                      </select>
                </div>
                {/* <div className="offset-md-2 col-md-8">
                      <h5>Event:</h5>
                      <input type="text" className="form-control mb-3" id="event" style={{color:'black'}} placeholder="Event"/>
                    </div> */}
                {
                    forminput
                }
                
            </div>
        </form>



           
        </>
        )


    }
}
