import React, { Component } from 'react'

export default class Header extends Component {
    render() {
        return (
                <header id="header" className="alt">
						<a href="index.html" className="logo"><strong>Forty</strong> <span>by HTML5 UP</span></a>
						<nav>
							<a href="#menu">Menu</a>
						</nav>
				</header>
        )
    }
}
