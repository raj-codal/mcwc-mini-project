import React, { Component } from 'react'
import Particles from 'react-particles-js'
import { Link, animateScroll as scroll } from "react-scroll"


class main extends Component {
    
    checkEvents = (e) => {
        document.getElementById('events').focus();
    }

    scrollToTop = () => {
        scroll.scrollToTop(); 
    };

    scrollToEvents = () => {
        scroll.scrollTo('events');
        // scroll.scrollMore(500);
    }
    
    render() {
        
        const particlesOptions = 
        {
            // particles: {
            //     line_linked: {
            //         shadow: {
            //             enable: true,
            //             color: "#ff00ff",
            //             blur: 5
            //         }
            //     },
            //     number: {
            //         value: 80,
            //         density: {
            //           enable: true,
            //           value_area: 800
            //         }
            //     } 
            // }
            
                "particles": {
                  "number": {
                    "value": 80,
                    "density": {
                      "enable": true,
                      "value_area": 500
                    }
                  },
                  "color": {
                    "value": "#ffffff"
                  },
                  
                  "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                      "enable": false,
                      "speed": 1,
                      "opacity_min": 0.1,
                      "sync": false
                    }
                  },
                  "line_linked": {
                    "enable": true,
                    "distance": 80,
                    "color": "#ffffff",
                    "opacity": 0.4,
                    "width": 1,
                    "blur": 5
                  },
                  "move": {
                    "enable": true,
                    "speed": 1,
                    "direction": "none",
                    "random": true,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                    "attract": {
                      "enable": false,
                      "rotateX": 600,
                      "rotateY": 1200
                    }
                  }
                },
                  
        }
      
        // {
        //     particles: {
        //       number: {
        //         value: 80,
        //         density: {
        //           enable: true,
        //           value_area: 800
        //         }
        //       }
        //     }
        // };

        var par = <Particles style={{zIndex: -20,height: '100%',position: "absolute"}} className="particles" params={particlesOptions} />
        

        return (
            <>
               
                <section style={{zIndex:20,minHeight:"100vh"}} className="section section-md section-hero main-section-1" id="particles-js" >
                    {par}
                    <a id="top"></a>
                    <div className="container shape-container d-flex align-items-center py-sm" id="p">
                    <div className="col px-0">
                        <div className="row align-items-center justify-content-center">
                        <div className="col-lg-7 text-center">
                            {/* <img className="img-fluid" style={{width: '200px'}} alt="hello" src="./assets/img/brand/white.png"/> */}
                            <h1 style={{color: "white",marginTop:"20vh"}}><b>CONVERSE 2k19</b></h1>
                            <p className="lead text-white" style={{fontSize:'2em'}}><b>A platform to showcase your technical skills<br/>6-7 September, 2019</b></p>
                            <p className="text-white">INFORMATION TECHNOLOGY DEPARTMENT,</p><p className="text-white">SARVAJANIK COLLEGE OF ENGINEERING & TECHNOLOGY, SURAT</p>
                            <div>
                                {this.props.linkDataEvent}
                                {this.props.linkDataRegister}
                                {/* <button className="btn btn-lg btn-white btn-icon mt-3 mb-sm-0" style={{width: '200px',borderRadius: '25px'}} onClick={this.props.toggleReg}>
                                    <span className="btn-inner--text">
                                    <span className="text-danger">REGISTER NOW</span></span>
                                </button> */}
                            </div>
                            
                        </div>
                        </div>
                    </div>
                    </div>
                    
                </section>
            </>
        )
    }
}

export default main


{/* <header className="header-global">
<nav className="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom headroom--not-bottom headroom--pinned headroom--top" id="navbar-main">
    <div className="container">
    <a className="navbar-brand mr-lg-5">
        <img src="https://avatars2.githubusercontent.com/u/43428556?s=400&u=b18c32e60aceaa993c1d9e14470c4a0c0ade46bd&v=4" onClick={this.scrollToTop} />
    </a>
    <button className="navbar-toggler" aria-expanded="false" aria-controls="navbar_global" aria-label="Toggle navigation" type="button" data-target="#navbar_global" data-toggle="collapse">
        <span className="navbar-toggler-icon"></span>
    </button>
    <div className="navbar-collapse collapse" id="navbar_global">
        <div className="navbar-collapse-header">
        <div className="row">
            <div className="col-6 collapse-brand">
            <a href="./index.html">
                <img src="./assets/img/brand/blue.png"/>
            </a>
            </div>
            <div className="col-6 collapse-close">
            <button className="navbar-toggler" aria-expanded="false" aria-controls="navbar_global" aria-label="Toggle navigation" type="button" data-target="#navbar_global" data-toggle="collapse">
                <span></span>
                <span></span>
            </button>
            </div>
        </div>
        </div>
        <ul className="navbar-nav navbar-nav-hover align-items-lg-center">
        <li className="nav-item dropdown">
            <a className="nav-link" role="button" href="#" data-toggle="dropdown">
            <i className="ni ni-ui-04 d-lg-none"></i>
            <span className="nav-link-inner--text">Components</span>
            </a>
            <div className="dropdown-menu dropdown-menu-xl">
            <div className="dropdown-menu-inner">
                <a className="media d-flex align-items-center" href="https://demos.creative-tim.com/argon-design-system/docs/getting-started/overview.html">
                <div className="icon icon-shape bg-gradient-primary rounded-circle text-white">
                    <i className="ni ni-spaceship"></i>
                </div>
                <div className="media-body ml-3">
                    <h6 className="heading text-primary mb-md-1">Getting started</h6>
                    <p className="description d-none d-md-inline-block mb-0">Learn how to use Argon compiling Scss, change brand colors and more.</p>
                </div>
                </a>
                <a className="media d-flex align-items-center" href="https://demos.creative-tim.com/argon-design-system/docs/foundation/colors.html">
                <div className="icon icon-shape bg-gradient-success rounded-circle text-white">
                    <i className="ni ni-palette"></i>
                </div>
                <div className="media-body ml-3">
                    <h6 className="heading text-primary mb-md-1">Foundation</h6>
                    <p className="description d-none d-md-inline-block mb-0">Learn more about colors, typography, icons and the grid system we used for Argon.</p>
                </div>
                </a>
                <a className="media d-flex align-items-center" href="https://demos.creative-tim.com/argon-design-system/docs/components/alerts.html">
                <div className="icon icon-shape bg-gradient-warning rounded-circle text-white">
                    <i className="ni ni-ui-04"></i>
                </div>
                <div className="media-body ml-3">
                    <h5 className="heading text-warning mb-md-1">Components</h5>
                    <p className="description d-none d-md-inline-block mb-0">Browse our 50 beautiful handcrafted components offered in the Free version.</p>
                </div>
                </a>
            </div>
            </div>
        </li>
        <li className="nav-item dropdown">
            <a className="nav-link" role="button" href="#" data-toggle="dropdown">
            <i className="ni ni-collection d-lg-none"></i>
            <span className="nav-link-inner--text">Examples</span>
            </a>
            <div className="dropdown-menu">
            <a className="dropdown-item" href="./examples/landing.html">Landing</a>
            <a className="dropdown-item" href="./examples/profile.html">Profile</a>
            <a className="dropdown-item" href="./examples/login.html">Login</a>
            <a className="dropdown-item" href="./examples/register.html">Register</a>
            </div>
        </li>
        </ul>
        <ul className="navbar-nav align-items-lg-center ml-lg-auto">
        <li className="nav-item">
            <a title="" className="nav-link nav-link-icon" href="https://www.facebook.com/creativetim" target="_blank" data-toggle="tooltip" data-original-title="Like us on Facebook">
            <i className="fa fa-facebook-square"></i>
            <span className="nav-link-inner--text d-lg-none">Facebook</span>
            </a>
        </li>
        <li className="nav-item">
            <a title="" className="nav-link nav-link-icon" href="https://www.instagram.com/creativetimofficial" target="_blank" data-toggle="tooltip" data-original-title="Follow us on Instagram">
            <i className="fa fa-instagram"></i>
            <span className="nav-link-inner--text d-lg-none">Instagram</span>
            </a>
        </li>
        <li className="nav-item">
            <a title="" className="nav-link nav-link-icon" href="https://twitter.com/creativetim" target="_blank" data-toggle="tooltip" data-original-title="Follow us on Twitter">
            <i className="fa fa-twitter-square"></i>
            <span className="nav-link-inner--text d-lg-none">Twitter</span>
            </a>
        </li>
        <li className="nav-item">
            <a title="" className="nav-link nav-link-icon" href="https://github.com/creativetimofficial/argon-design-system" target="_blank" data-toggle="tooltip" data-original-title="Star us on Github">
            <i className="fa fa-github"></i>
            <span className="nav-link-inner--text d-lg-none">Github</span>
            </a>
        </li>
        <li className="nav-item d-none d-lg-block ml-lg-4">
            <a className="btn btn-neutral btn-icon" href="https://www.creative-tim.com/product/argon-design-system" rel="noopener noreferrer" target="_blank">
            <span className="btn-inner--icon">
                <i className="fa fa-cloud-download mr-2"></i>
            </span>
            <span className="nav-link-inner--text">Download</span>
            </a>
        </li>
        </ul>
    </div>
    </div>
</nav>
</header> */}