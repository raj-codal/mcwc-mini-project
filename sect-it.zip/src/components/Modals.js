import React, { Component } from 'react';
import { Table, Modal, Button } from 'antd';
export default class Modals extends Component {
    state = {
        visible: false, 
        selectedRowKeys: [], // Check here to configure the default column
        loading: false,
      };
    showModal = () => {
        this.setState({
        visible: true,
        });
    };

    handleOk = e => {
        console.log(e);
        this.setState({
        visible: false,
        });
    };

    handleCancel = e => {
        console.log(e);
        this.setState({
        visible: false,
        });
    };

    onSelectChange = selectedRowKeys => {
        // console.log('selectedRowKeys changed: ', selectedRowKeys);
        this.setState({ selectedRowKeys });
    };


    

    render() {
        const columns = [
            {
                title: 'No.',
              dataIndex: 'no',
            },
            {
                title: 'Rule',
              dataIndex: 'rule',
            }
          ];
          
          this.data = []

          for (let i = 0; i < this.props.rules.length; i++) {
            this.data.push({
              key: i,
              no: i+1,
              rule: this.props.rules[i],
            });
        }
        
        const { loading, selectedRowKeys } = this.state;
        const rowSelection = {
        selectedRowKeys,
        onChange: this.onSelectChange,
        };
        const hasSelected = selectedRowKeys.length > 0;
        
        return (
            <div>
                 <div style={{zIndex : "30"}}>
                    <Button type="danger" onClick={this.showModal} style={{padding:'0 25px 0 25px',left:"50%",transform:'translateX(-50%)'}}>
                        RULES
                    </Button>
                    <Modal
                    title={this.props.eventname}
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    footer = {[<Button key="submit" type="primary" onClick={this.handleCancel}>
                                OK
                                </Button>]}
                    >
                        <Table pagination={{defaultPageSize:3}} columns={columns} dataSource={this.data} size="small"/>

                    </Modal>
                </div>
            </div>
        )
    }
}
