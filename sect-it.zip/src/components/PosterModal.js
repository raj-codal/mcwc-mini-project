import React, { Component } from 'react';
import { Modal, Button } from 'antd';
export default class PosterModal extends Component {
    state = {
        visible: false, 
        selectedRowKeys: [], // Check here to configure the default column
        loading: false,
      };
    showModal = () => {
        this.setState({
        visible: true,
        });
    };

    handleOk = e => {
        console.log(e);
        this.setState({
        visible: false,
        });
    };

    handleCancel = e => {
        console.log(e);
        this.setState({
        visible: false,
        });
    };

    onSelectChange = selectedRowKeys => {
        // console.log('selectedRowKeys changed: ', selectedRowKeys);
        this.setState({ selectedRowKeys });
    };


    

    render() {
        // const columns = [
        //     {
        //         title: 'No.',
        //       dataIndex: 'no',
        //     },
        //     {
        //         title: 'Rule',
        //       dataIndex: 'rule',
        //     }
        //   ];
          
          
        // }
        
        // const { loading, selectedRowKeys } = this.state;
        // const rowSelection = {
        // selectedRowKeys,
        // onChange: this.onSelectChange,
        // };
        // const hasSelected = selectedRowKeys.length > 0;
        
        return (
            <div>
                 <div style={{zIndex : "30"}}>
                    <img style={{width:"100%"}} src={this.props.image} onClick={this.showModal}/>
                    
                    <Modal
                    title=""
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    footer = {[<Button key="submit" type="primary" onClick={this.handleCancel}>
                                OK
                                </Button>]}
                    >
                     <br/>   
                    <img className="mr-auto ml-auto" style={{height:"100vh"}} src={this.props.image}/>
                    {/* <img className="mr-auto ml-auto" style={{height:"100vh"}} src="eventposters/pyit.jpeg"/> */}

                    </Modal>
                </div>
            </div>
        )
    }
}
