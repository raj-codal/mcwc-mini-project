import React, { Component } from 'react'

export default class Team extends Component {
    render() {
        return (
            <>
                <hr/>
                <div className="container">

                    <center><h1>CONVERSE 2K19 TEAM</h1></center>
                    
                    <div className="row mt-5">
                        <div className="col-12 pt-0 pl-2 pr-2">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-users"></i>
                                </div>
                                <h4>CONVERSE 2k19</h4>
                                Faculty Coordinators
                                <br/>• Prof. Hiren Vaviya 
                                <br/>• Prof. Dhanlakshmi Manikraj
                                <br/>
                                <br/><br/>Student Conveners
                                <br/>• Raj Dhanani 
                                <br/>• Jinam Mehta   
                                <br/>• Samarth Mehta   
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pt-0 pl-2 pr-2 ml-auto mr-auto">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-black-tie"></i>
                                </div>
                                <h4>PY IT</h4>
                                Faculty Coordinators
                                <br/>• Prof. Mukesh Patel  
                                <br/>• Prof. (Dr.) Mita Parikh
                                <br/><br/>Student Event Heads
                                <br/>• Pranav Desai 
                                <br/>• Ayush Vyas  
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pt-0 pl-2 pr-2 ml-auto mr-auto">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-codiepie"></i>
                                </div>
                                <h4>C Quiz</h4>
                                Faculty Coordinators
                                <br/>• Prof. Mukesh Patel  
                                <br/>• Prof. Tushar Gohil
                                <br/><br/>Student Event Heads
                                <br/>• Ashish Chovatiya
                                <br/>• Shreya Brahmbhatt
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pt-0 pl-2 pr-2 ml-auto mr-auto">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-laptop"></i>
                                </div>
                                <h4>IT Quiz</h4>
                                Faculty Coordinators
                                <br/>• Prof. Ashish Kharvar
                                <br/>• Prof. Apurva Mandalaywala
                                <br/><br/>Student Event Heads
                                <br/>• Arpan Korat
                                <br/>• Parth Buha   
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pt-0 pl-2 pr-2 ml-auto mr-auto">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-code"></i>
                                </div>
                                <h4>WYSIWYG</h4>
                                Faculty Coordinators
                                <br/>• Prof. Bhumika Patel  
                                <br/>• Prof. Tushar Gohil
                                <br/><br/>Student Event Heads
                                <br/>• Akash Chovatiya
                                <br/>• Devanshi Jadav
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pt-0 pl-2 pr-2 ml-auto mr-auto">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-terminal"></i>
                                </div>
                                <h4>Relay Coding</h4>
                                Faculty Coordinators<br/>
                                <br/>• Prof. Tushar Gohil
                                <br/><br/>Student Event Heads
                                <br/>• Riddhi Chodvadiya 
                                <br/>• Vishal Tailor
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pt-0 pl-2 pr-2 ml-auto mr-auto">
                            <div className="iconBox" style = {obj}>
                                <div className = "icon">
                                    <i className="fa fa-paint-brush"></i>
                                </div>
                                <h4>Image IT</h4>
                                Faculty Coordinators<br/>
                                <br/>• Prof. Dhruti Sharma
                                <br/>• Prof. Dhanalakshmi Manikraj
                                <br/><br/>Student Event Heads
                                <br/>• Siddharth Simediya
                                <br/>• Moksha Shah   
                            </div>
                        </div>
                        
                    </div>
                </div>
            </>
        )
    }
}

var obj = {
    marginTop : "50px",
    border : "1px #f0f0f0 solid",
    paddingTop : "50px",
    paddingLeft : "10px",
    paddingRight : "10px",
    paddingBottom : "10px",
    backgroundColor : "#f9f9f9",
    textAlign : "center",
    verticalAlign : "middle"
}